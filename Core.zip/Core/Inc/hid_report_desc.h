#ifndef __HID_REPORT_DESC_H
#define __HID_REPORT_DESC_H

#include "usbd_def.h"
#include <stdint.h>

/* Option A: 4 axis + 12 buttons
   Report descriptor size will be a compile-time constant.
   IMPORTANT: update this value if you change the descriptor bytes. */
#define HID_REPORT_DESC_FS_SIZE   74U   /* <-- số ví dụ, anh sẽ dán đúng descriptor thì em chốt con số này */

/* Provide a complete type for sizeof in other modules */
extern const uint8_t HID_ReportDesc_FS[HID_REPORT_DESC_FS_SIZE];

#endif
