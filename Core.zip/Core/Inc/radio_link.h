#ifndef RADIO_LINK_H
#define RADIO_LINK_H

#include <stdint.h>
#include "usart.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int8_t  uplink_rssi1_dbm_neg;   // payload lưu dạng (dBm * -1)
    int8_t  uplink_rssi2_dbm_neg;
    uint8_t uplink_lq_percent;      // 0..100
    int8_t  uplink_snr_db;

    uint8_t rf_mode;               // enum theo CRSF
    uint8_t tx_power;              // enum theo CRSF

    int8_t  downlink_rssi_dbm_neg;
    uint8_t downlink_lq_percent;
    int8_t  downlink_snr_db;

    uint32_t last_update_ms;        // tick khi nhận frame gần nhất
} radio_link_stats_t;

void radio_link_init(UART_HandleTypeDef* huart, uint32_t now_ms);

// Gửi kênh RC (16ch, giá trị CRSF 11-bit “172..1811” như bạn đang dùng)
void radio_link_send_channels(const uint16_t ch16[16]);

// gọi khi nhận 1 byte từ UART (RX interrupt)
void radio_link_on_rx_byte(uint8_t b, uint32_t now_ms);

// lấy stats mới nhất để hiển thị
radio_link_stats_t radio_link_get_stats(void);

// failsafe helper
void radio_link_apply_failsafe(uint16_t ch16[16],
                               uint32_t now_ms,
                               uint32_t last_input_ms,
                               uint32_t timeout_ms);

#ifdef __cplusplus
}
#endif

#endif
