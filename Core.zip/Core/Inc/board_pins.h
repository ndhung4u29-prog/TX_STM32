#ifndef _BOARD_PINS_H_
#define _BOARD_PINS_H_

#include "main.h"

//---------------------------------------------------------------------
//  ADC INPUT (TỪ MUX 74HC4067) → PA0
//---------------------------------------------------------------------
#define MUX_ADC_GPIO        GPIOA
#define MUX_ADC_PIN         GPIO_PIN_0

//---------------------------------------------------------------------
//  CHÂN ĐIỀU KHIỂN 74HC4067 (S0–S3) — Mapping theo hình anh gửi
//---------------------------------------------------------------------
#define MUX_S0_GPIO         GPIOC
#define MUX_S0_PORT         GPIOC
#define MUX_S0_PIN          GPIO_PIN_0

#define MUX_S1_GPIO         GPIOC
#define MUX_S1_PORT         GPIOC
#define MUX_S1_PIN          GPIO_PIN_1

#define MUX_S2_GPIO         GPIOC
#define MUX_S2_PORT         GPIOC
#define MUX_S2_PIN          GPIO_PIN_2

#define MUX_S3_GPIO         GPIOC
#define MUX_S3_PORT         GPIOC
#define MUX_S3_PIN          GPIO_PIN_3

//---------------------------------------------------------------------
//  NÚT NHẤN
//---------------------------------------------------------------------
#define BTN_OK_GPIO         GPIOA
#define BTN_OK_PORT         GPIOA
#define BTN_OK_PIN          GPIO_PIN_8

#define BTN_BACK_GPIO       GPIOB
#define BTN_BACK_PORT       GPIOB
#define BTN_BACK_PIN        GPIO_PIN_2

#define BTN_UP_GPIO         GPIOC
#define BTN_UP_PORT         GPIOC
#define BTN_UP_PIN          GPIO_PIN_14

#define BTN_DOWN_GPIO       GPIOC
#define BTN_DOWN_PORT       GPIOC
#define BTN_DOWN_PIN        GPIO_PIN_15

//---------------------------------------------------------------------
//  I2C OLED SSD1309 & EEPROM 24C256 — dùng I2C1 PB6/PB7
//---------------------------------------------------------------------
#define OLED_I2C            hi2c1
#define OLED_I2C_ADDR       (0x3C << 1)

#endif
