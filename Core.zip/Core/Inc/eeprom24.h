#ifndef __EEPROM24_H
#define __EEPROM24_H

#include "main.h"

HAL_StatusTypeDef EEPROM24_Init(uint8_t addr);
HAL_StatusTypeDef EEPROM24_Write(uint16_t memAddr, uint8_t* data, uint16_t len);
HAL_StatusTypeDef EEPROM24_Read(uint16_t memAddr, uint8_t* data, uint16_t len);

#endif
