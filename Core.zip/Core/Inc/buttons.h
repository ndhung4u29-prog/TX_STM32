#pragma once
#include <stdint.h>
#include "stm32f4xx_hal.h"

// Bit layout (phải khớp oled_ui.c)
#define BTN_ST1_BIT   (1u << 0)
#define BTN_ST2_BIT   (1u << 1)
#define BTN_ST3_BIT   (1u << 2)
#define BTN_ST4_BIT   (1u << 3)
#define BTN_ST5_BIT   (1u << 4)
#define BTN_ST6_BIT   (1u << 5)
#define BTN_ST7_BIT   (1u << 6)
#define BTN_ST8_BIT   (1u << 7)

#define BTN_OK_BIT    (1u << 8)
#define BTN_BACK_BIT  (1u << 9)
#define BTN_UP_BIT    (1u << 10)   // UP/DOWN lấy từ MUX (C14/C15) -> main.c sẽ OR vào
#define BTN_DOWN_BIT  (1u << 11)

#define BTN_NAV_MASK  (BTN_OK_BIT | BTN_BACK_BIT | BTN_UP_BIT | BTN_DOWN_BIT)

void     Buttons_Init(void);       // nếu anh không khai báo CubeMX thì BẮT BUỘC gọi
uint16_t Buttons_ReadMask(void);   // đọc OK/BACK + 8 subtrim (active-low)
