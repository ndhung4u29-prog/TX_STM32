#ifndef __OLED_BASIC_H
#define __OLED_BASIC_H

#include "main.h"
#include <stdint.h>

// SSD1309 / SSD1306 thường dùng địa chỉ 7-bit 0x3C (8-bit = 0x78)
// (Anh đang dùng 0x3C theo mô tả)
#define OLED_ADDR   (0x3C << 1)

void OLED_Init(void);
void OLED_Clear(void);
void OLED_Refresh(void);

void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t color);
void OLED_DrawChar6x8(uint8_t x, uint8_t y, char c);
void OLED_Print6x8(uint8_t x, uint8_t y, const char *str);

void OLED_DrawBar(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t percent);
void OLED_DrawFrame(uint8_t x, uint8_t y, uint8_t w, uint8_t h);

#endif
