/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
/* ==== BUTTON PIN MAP (đã remap để nhường PA11/PA12 cho USB) ==== */
#define BTN_OK_GPIO_Port         GPIOA
#define BTN_OK_Pin               GPIO_PIN_8         // Menu OK

#define BTN_BACK_GPIO_Port       GPIOB
#define BTN_BACK_Pin             GPIO_PIN_2         // Menu Back (đổi từ PA11)

#define CH1_BT1_GPIO_Port        GPIOC
#define CH1_BT1_Pin              GPIO_PIN_14        // CH1-BT1 (đổi từ PA12)

#define CH1_BT2_GPIO_Port        GPIOA
#define CH1_BT2_Pin              GPIO_PIN_15

#define CH2_BT1_GPIO_Port        GPIOB
#define CH2_BT1_Pin              GPIO_PIN_3

#define CH2_BT2_GPIO_Port        GPIOB
#define CH2_BT2_Pin              GPIO_PIN_4

#define CH3_BT1_GPIO_Port        GPIOB
#define CH3_BT1_Pin              GPIO_PIN_5

#define CH3_BT2_GPIO_Port        GPIOA
#define CH3_BT2_Pin              GPIO_PIN_1

#define CH4_BT1_GPIO_Port        GPIOB
#define CH4_BT1_Pin              GPIO_PIN_0

#define CH4_BT2_GPIO_Port        GPIOB
#define CH4_BT2_Pin              GPIO_PIN_1

/* ==== LED / BUZZER ==== */
#define LED_GPIO_Port            GPIOC
#define LED_Pin                  GPIO_PIN_13

#define BUZZER_GPIO_Port         GPIOB
#define BUZZER_Pin               GPIO_PIN_8

/* ==== 74HC4067 (MUX) ==== */
#define MUX_S0_GPIO_Port         GPIOB
#define MUX_S0_Pin               GPIO_PIN_12
#define MUX_S1_GPIO_Port         GPIOB
#define MUX_S1_Pin               GPIO_PIN_13
#define MUX_S2_GPIO_Port         GPIOB
#define MUX_S2_Pin               GPIO_PIN_14
#define MUX_S3_GPIO_Port         GPIOB
#define MUX_S3_Pin               GPIO_PIN_15
/* MUX SIG -> ADC1_IN0 @ PA0 (đã cấu hình ở CubeMX) */

/* ==== USB VBUS sense (nếu có cầu chia 100k/100k) ==== */
#define VBUS_SENSE_GPIO_Port     GPIOA
#define VBUS_SENSE_Pin           GPIO_PIN_9

/* ==== BIT MASK cho Buttons_ReadMask() ==== */
/* Giữ layout cũ để không phải sửa nhiều chỗ:
   bit0 = UP   (CH1_BT1), bit1 = DOWN (CH1_BT2)
   bit8 = OK   (BTN_OK),  bit9 = BACK (BTN_BACK)
*/



/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
