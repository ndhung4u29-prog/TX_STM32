#pragma once
#include <stdint.h>

extern uint16_t g_adc_raw[16];

void MUX_Init(void);
void MUX_UpdateAll(void);
