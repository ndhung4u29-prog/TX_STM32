#ifndef __OLED_UI_H
#define __OLED_UI_H

#include <stdint.h>

typedef struct {
    // Raw ADC (0..4095)
    uint16_t ax_raw;
    uint16_t ay_raw;
    uint16_t az_raw;
    uint16_t arx_raw;
    uint16_t vbat_raw;
    uint16_t pot1_raw;
    uint16_t pot2_raw;
    uint16_t pot3_raw;
    uint16_t sw2_1_raw;
    uint16_t sw2_2_raw;
    uint16_t sw2_3_raw;
    uint16_t sw2_4_raw;
    uint16_t sw3_1_raw;
    uint16_t sw3_2_raw;

    // Buttons mask (bit0..bit11 như Buttons_ReadMask)
    uint16_t btn_mask;

    // VBAT (đã ước lượng, Volt)
    float vbat;

    // Telemetry
    uint8_t lq;
    int8_t  rssi_dbm; // giá trị “-dBm” hiển thị cho dễ đọc
    int8_t  snr_db;
    uint32_t link_age_ms;
} OLED_UI_Input_t;

void OLED_UI_Init(void);
void OLED_UI_Render(const OLED_UI_Input_t* in);

#endif
