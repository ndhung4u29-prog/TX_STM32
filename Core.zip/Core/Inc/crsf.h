#ifndef CRSF_H
#define CRSF_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// ===================== CRSF constants =====================
#define CRSF_TYPE_RC_CHANNELS_PACKED   0x16u
#define CRSF_TYPE_LINK_STATISTICS      0x14u   // optional telemetry
// Extended frames (device/parameter)
#define CRSF_TYPE_DEVICE_PING              0x28u
#define CRSF_TYPE_DEVICE_INFO              0x29u
#define CRSF_TYPE_PARAMETER_SETTINGS_ENTRY 0x2Bu
#define CRSF_TYPE_PARAMETER_READ           0x2Cu
#define CRSF_TYPE_PARAMETER_WRITE          0x2Du
#define CRSF_TYPE_COMMAND                  0x32u

// Common CRSF device addresses (sync byte / destination)
#define CRSF_ADDR_BROADCAST            0x00u
#define CRSF_ADDR_USB                  0x10u
#define CRSF_ADDR_TBS_CORE_PNP_PRO     0x80u
#define CRSF_ADDR_RESERVED1            0x8Au
#define CRSF_ADDR_CURRENT_SENSOR       0xC0u
#define CRSF_ADDR_GPS                  0xC2u
#define CRSF_ADDR_TBS_BLACKBOX         0xC4u
#define CRSF_ADDR_FLIGHT_CONTROLLER    0xC8u
#define CRSF_ADDR_RESERVED2            0xCAu
#define CRSF_ADDR_RACE_TAG             0xCCu
#define CRSF_ADDR_VTX                  0xCEu
#define CRSF_ADDR_RADIO_TRANSMITTER    0xEAu
#define CRSF_ADDR_CRSF_RECEIVER        0xECu
#define CRSF_ADDR_CRSF_TRANSMITTER     0xEEu   // often used for TX->TX module

// Channel value range commonly used
#define CRSF_CH_MIN                    172u
#define CRSF_CH_MID                    992u
#define CRSF_CH_MAX                    1811u

// Payload sizes
#define CRSF_RC_PAYLOAD_LEN            22u
#define CRSF_FRAME_MAX_LEN             64u     // safe cap for parser

// ===================== Frame struct (parser output) =====================
typedef struct {
    uint8_t addr;          // first byte
    uint8_t len;           // second byte
    uint8_t type;          // third byte
    const uint8_t* payload;// points into internal buffer
    uint8_t payload_len;   // len - 2 (type + crc)
    uint8_t crc;           // last byte
} crsf_frame_t;

// Callback invoked when a valid frame is parsed
typedef void (*crsf_on_frame_fn)(const crsf_frame_t* f, void* user);

// ===================== Builder API (TX) =====================
// Build RC_CHANNELS_PACKED frame into out_buf.
// Returns number of bytes written, or 0 if out_buf too small.
//
// out frame format:
// [addr][len][type][payload 22][crc]
//
// crc is CRC8/DVB-S2 computed over [type + payload]
size_t crsf_build_rc_channels_frame(uint8_t* out_buf,
                                   size_t out_buf_size,
                                   uint8_t addr,
                                   const uint16_t ch16[16]);
size_t crsf_build_ext_frame(uint8_t* out,
                            size_t out_size,
                            uint8_t addr,      // usually CRSF_ADDR_CRSF_TRANSMITTER (0xEE)
                            uint8_t type,      // 0x28.. etc
                            uint8_t dst,       // destination in ext header
                            uint8_t src,       // origin in ext header
                            const uint8_t* payload,
                            size_t payload_len);

size_t crsf_build_device_ping(uint8_t* out, size_t out_size, uint8_t addr, uint8_t dst, uint8_t src);
size_t crsf_build_param_read(uint8_t* out, size_t out_size, uint8_t addr, uint8_t dst, uint8_t src, uint8_t param_index, uint8_t chunk);
size_t crsf_build_param_write_u8(uint8_t* out, size_t out_size, uint8_t addr, uint8_t dst, uint8_t src, uint8_t param_index, uint8_t value_u8);

// Helpers to map input to CRSF channel range
uint16_t crsf_map_adc12_to_channel(uint16_t raw12);          // 0..4095 -> 172..1811
uint16_t crsf_map_i16_centered_to_channel(int16_t v);        // ~ -32768..+32767 -> 172..1811 centered
uint16_t crsf_sw2_to_channel(uint16_t raw);                  // raw threshold -> MIN/MAX
uint16_t crsf_sw3pos_to_channel(uint8_t pos);                // 0 mid,1 up,2 down -> MID/MAX/MIN

// ===================== Parser API (RX optional) =====================
typedef struct {
    uint8_t buf[CRSF_FRAME_MAX_LEN];
    uint8_t idx;
    uint8_t expected; // total bytes expected for a frame
    crsf_on_frame_fn cb;
    void* user;
} crsf_parser_t;

void crsf_parser_init(crsf_parser_t* p, crsf_on_frame_fn cb, void* user);
void crsf_parser_reset(crsf_parser_t* p);
// Feed one byte at a time (from UART RX interrupt)
void crsf_parser_feed(crsf_parser_t* p, uint8_t b);

#ifdef __cplusplus
}
#endif

#endif // CRSF_H
