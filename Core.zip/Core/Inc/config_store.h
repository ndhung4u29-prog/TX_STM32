#ifndef __CONFIG_STORE_H
#define __CONFIG_STORE_H
#pragma once
#include <stdint.h>
#include "main.h"

typedef struct
{
    uint16_t magic;
    int16_t trim[6];
    uint8_t reverse[6];
    uint8_t rates[6];
    // ===== CALIB =====
        // idx: 0 AX, 1 AY, 2 AZ, 3 AR, 4 P1, 5 P2, 6 P3
        uint16_t cal_min[7];
        uint16_t cal_max[7];
        uint16_t cal_ctr[7];
} Config_t;

extern Config_t gConfig;

void Config_Load(void);
void Config_Save(void);
void Config_ResetDefaults(void);

#endif
