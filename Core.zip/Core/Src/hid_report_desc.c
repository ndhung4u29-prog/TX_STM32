#include "usbd_hid.h"
#include "hid_report_desc.h"
/* HID REPORT DESCRIPTOR FOR DIRECTINPUT JOYSTICK
 * 4 axes  (X, Y, Z, Rx) → 4 * 16-bit
 * 20 buttons → 12 bits + 4 bits padding
 * Total report = 8 bytes axis + 3 bytes buttons = 11 bytess
 */
__ALIGN_BEGIN const uint8_t HID_ReportDesc_FS[] __ALIGN_END =
{
    0x05, 0x01,       // USAGE_PAGE (Generic Desktop)
    0x09, 0x04,       // USAGE (Joystick)
    0xA1, 0x01,       // COLLECTION (Application)

    // ---------------- AXES --------------------
    0xA1, 0x00,       // COLLECTION (Physical)
    0x05, 0x01,       //   Usage Page (Generic Desktop)
    0x09, 0x30,       //   Usage X
    0x09, 0x31,       //   Usage Y
    0x09, 0x32,       //   Usage Z
    0x09, 0x33,       //   Usage Rx

    0x15, 0x00,       //   Logical Min (0)
    0x26, 0xFF, 0xFF, //   Logical Max (65535)
    0x75, 0x10,       //   Report Size 16 bits
    0x95, 0x04,       //   Report Count (4 axes)
    0x81, 0x02,       //   Input (Data, Var, Abs)
    0xC0,             // END COLLECTION

    // -------------- BUTTONS -------------------
    0x05, 0x09,       // USAGE_PAGE (Button)
    0x19, 0x01,       // USAGE_MIN (Button 1)
    0x29, 0x14,       // USAGE_MAX (Button 20)
    0x15, 0x00,       // Logical Min (0)
    0x25, 0x01,       // Logical Max (1)
    0x75, 0x01,       // Report Size 1 bit
    0x95, 0x14,       // Report Count 20 buttons
    0x81, 0x02,       // Input (Data, Var, Abs)

    // Padding 4 bits (để tròn 3 byte cho phần buttons)
    0x75, 0x01,
    0x95, 0x04,
    0x81, 0x03,       // Const, Var, Abs

    0xC0              // END COLLECTION
};

