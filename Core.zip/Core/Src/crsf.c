#include "crsf.h"
#include <string.h>

// ===================== CRC8 DVB-S2 (poly 0xD5) =====================
static uint8_t crsf_crc8_dvb_s2(const uint8_t* data, uint32_t len)
{
    uint8_t crc = 0x00;
    for (uint32_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (uint8_t b = 0; b < 8; b++) {
            crc = (crc & 0x80u) ? (uint8_t)((crc << 1) ^ 0xD5u) : (uint8_t)(crc << 1);
        }
    }
    return crc;
}

static uint16_t clamp11(uint16_t v)
{
    return (v > 2047u) ? 2047u : v;
}

// Pack 16 channels x 11-bit into 22 bytes (little-endian bit packing)
static void crsf_pack_channels_16x11(uint8_t out22[CRSF_RC_PAYLOAD_LEN], const uint16_t ch16[16])
{
    uint32_t bitbuf = 0;
    uint8_t bits = 0;
    uint8_t idx = 0;

    for (uint8_t c = 0; c < 16; c++) {
        uint16_t v = clamp11(ch16[c]);
        bitbuf |= ((uint32_t)v) << bits;
        bits += 11;

        while (bits >= 8) {
            out22[idx++] = (uint8_t)(bitbuf & 0xFFu);
            bitbuf >>= 8;
            bits -= 8;
            if (idx >= CRSF_RC_PAYLOAD_LEN) break;
        }
    }
    while (idx < CRSF_RC_PAYLOAD_LEN) {
        out22[idx++] = (uint8_t)(bitbuf & 0xFFu);
        bitbuf >>= 8;
    }
}

// ===================== Builder =====================
size_t crsf_build_rc_channels_frame(uint8_t* out_buf,
                                   size_t out_buf_size,
                                   uint8_t addr,
                                   const uint16_t ch16[16])
{
    // total = addr(1) + len(1) + type(1) + payload(22) + crc(1) = 26 bytes
    const size_t total = 1u + 1u + 1u + CRSF_RC_PAYLOAD_LEN + 1u;
    if (!out_buf || !ch16) return 0;
    if (out_buf_size < total) return 0;

    uint8_t payload[CRSF_RC_PAYLOAD_LEN];
    crsf_pack_channels_16x11(payload, ch16);

    out_buf[0] = addr;
    out_buf[1] = (uint8_t)(CRSF_RC_PAYLOAD_LEN + 2u); // type + payload + crc? (CRSF len field = type+payload+crc = payload+2)
    out_buf[2] = (uint8_t)CRSF_TYPE_RC_CHANNELS_PACKED;

    memcpy(&out_buf[3], payload, CRSF_RC_PAYLOAD_LEN);

    // CRC over [type + payload] => 1 + 22 bytes starting at out_buf[2]
    out_buf[3 + CRSF_RC_PAYLOAD_LEN] = crsf_crc8_dvb_s2(&out_buf[2], 1u + CRSF_RC_PAYLOAD_LEN);
    return total;
}

// ===================== Mapping helpers =====================
uint16_t crsf_map_adc12_to_channel(uint16_t raw12)
{
    // 0..4095 -> 172..1811
    uint32_t span = (uint32_t)(CRSF_CH_MAX - CRSF_CH_MIN);
    uint32_t v = (uint32_t)CRSF_CH_MIN + (span * (uint32_t)raw12) / 4095u;
    return (uint16_t)v;
}

uint16_t crsf_map_i16_centered_to_channel(int16_t v)
{
    // Map centered signed to around MID
    int32_t span_hi = (int32_t)CRSF_CH_MAX - (int32_t)CRSF_CH_MID; // 819
    int32_t span_lo = (int32_t)CRSF_CH_MID - (int32_t)CRSF_CH_MIN; // 820
    int32_t out;

    if (v >= 0) {
        out = (int32_t)CRSF_CH_MID + ((int32_t)v * span_hi) / 32767;
    } else {
        out = (int32_t)CRSF_CH_MID + ((int32_t)v * span_lo) / 32768;
    }

    if (out < (int32_t)CRSF_CH_MIN) out = CRSF_CH_MIN;
    if (out > (int32_t)CRSF_CH_MAX) out = CRSF_CH_MAX;
    return (uint16_t)out;
}

uint16_t crsf_sw2_to_channel(uint16_t raw)
{
    return (raw > 2048u) ? CRSF_CH_MAX : CRSF_CH_MIN;
}

uint16_t crsf_sw3pos_to_channel(uint8_t pos)
{
    // pos: 0 mid, 1 up, 2 down
    if (pos == 1u) return CRSF_CH_MAX;
    if (pos == 2u) return CRSF_CH_MIN;
    return CRSF_CH_MID;
}

// ===================== Parser (optional RX) =====================
void crsf_parser_init(crsf_parser_t* p, crsf_on_frame_fn cb, void* user)
{
    if (!p) return;
    memset(p, 0, sizeof(*p));
    p->cb = cb;
    p->user = user;
}

void crsf_parser_reset(crsf_parser_t* p)
{
    if (!p) return;
    p->idx = 0;
    p->expected = 0;
}

static void parser_try_emit(crsf_parser_t* p)
{
    // minimal sanity:
    // buf[0]=addr, buf[1]=len, total expected = len + 2 (addr+len field)
    if (p->idx < 4) return;

    uint8_t addr = p->buf[0];
    uint8_t len  = p->buf[1];
    uint8_t type = p->buf[2];

    uint8_t total = (uint8_t)(len + 2u);
    if (total != p->expected) return;
    if (total < 4u || total > CRSF_FRAME_MAX_LEN) return;

    // payload_len = len - 2 (type + crc)
    if (len < 2u) return;
    uint8_t payload_len = (uint8_t)(len - 2u);

    const uint8_t* payload = &p->buf[3];
    uint8_t crc = p->buf[3u + payload_len];

    // CRC check over [type + payload]
    uint8_t calc = crsf_crc8_dvb_s2(&p->buf[2], (uint32_t)(1u + payload_len));
    if (calc != crc) return;

    if (p->cb) {
        crsf_frame_t f;
        f.addr = addr;
        f.len = len;
        f.type = type;
        f.payload = payload;
        f.payload_len = payload_len;
        f.crc = crc;
        p->cb(&f, p->user);
    }
}

void crsf_parser_feed(crsf_parser_t* p, uint8_t b)
{
    if (!p) return;

    // Start of frame: first byte is address, second is len
    if (p->idx == 0) {
        p->buf[p->idx++] = b;
        return;
    }

    if (p->idx == 1) {
        p->buf[p->idx++] = b;
        uint8_t len = b;
        uint8_t total = (uint8_t)(len + 2u);
        if (total < 4u || total > CRSF_FRAME_MAX_LEN) {
            crsf_parser_reset(p);
            return;
        }
        p->expected = total;
        return;
    }

    // Collect until expected length
    if (p->idx < CRSF_FRAME_MAX_LEN) {
        p->buf[p->idx++] = b;
    } else {
        crsf_parser_reset(p);
        return;
    }

    if (p->expected && p->idx >= p->expected) {
        parser_try_emit(p);
        crsf_parser_reset(p);
    }
}
size_t crsf_build_ext_frame(uint8_t* out,
                            size_t out_size,
                            uint8_t addr,
                            uint8_t type,
                            uint8_t dst,
                            uint8_t src,
                            const uint8_t* payload,
                            size_t payload_len)
{
    // Frame: [addr][len][type][dst][src][payload...][crc]
    // len counts from type .. crc (type + extHeader(2) + payload + crc)
    const size_t needed = 1 + 1 + 1 + 2 + payload_len + 1;
    if (!out || out_size < needed) return 0;

    out[0] = addr;
    out[1] = (uint8_t)(1 + 2 + payload_len + 1); // type + dst/src + payload + crc
    out[2] = type;
    out[3] = dst;
    out[4] = src;

    for (size_t i = 0; i < payload_len; i++) out[5 + i] = payload[i];

    // CRC8 DVB-S2 poly 0xD5, over [type..endPayload] (NOT include addr/len)
    const uint8_t* crc_start = &out[2];
    const size_t crc_len = 1 + 2 + payload_len;
    out[5 + payload_len] = crsf_crc8_dvb_s2(crc_start, crc_len);

    return needed;
}

size_t crsf_build_device_ping(uint8_t* out, size_t out_size, uint8_t addr, uint8_t dst, uint8_t src)
{
    // payload empty for general ping
    return crsf_build_ext_frame(out, out_size, addr, CRSF_TYPE_DEVICE_PING, dst, src, NULL, 0);
}

size_t crsf_build_param_read(uint8_t* out, size_t out_size,
                             uint8_t addr, uint8_t dst, uint8_t src,
                             uint8_t param_index, uint8_t chunk)
{
    // payload: [param_index][chunk]
    uint8_t pl[2] = { param_index, chunk };
    return crsf_build_ext_frame(out, out_size, addr, CRSF_TYPE_PARAMETER_READ, dst, src, pl, sizeof(pl));
}

size_t crsf_build_param_write_u8(uint8_t* out, size_t out_size,
                                 uint8_t addr, uint8_t dst, uint8_t src,
                                 uint8_t param_index, uint8_t value_u8)
{
    // payload: [param_index][value...]
    uint8_t pl[2] = { param_index, value_u8 };
    return crsf_build_ext_frame(out, out_size, addr, CRSF_TYPE_PARAMETER_WRITE, dst, src, pl, sizeof(pl));
}
