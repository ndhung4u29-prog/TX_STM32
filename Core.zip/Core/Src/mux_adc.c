#include "mux_adc.h"
#include "adc.h"
#include "main.h"   // để có GPIOx, GPIO_PIN_x

#define MUX_CHANNEL_COUNT 16
#define ADC_SAMPLES       4

// Pin mapping theo main.c: PB12..PB15
#define MUX_S0_Port GPIOB
#define MUX_S0_Pin  GPIO_PIN_12
#define MUX_S1_Port GPIOB
#define MUX_S1_Pin  GPIO_PIN_13
#define MUX_S2_Port GPIOB
#define MUX_S2_Pin  GPIO_PIN_14
#define MUX_S3_Port GPIOB
#define MUX_S3_Pin  GPIO_PIN_15

uint16_t g_adc_raw[MUX_CHANNEL_COUNT] = {0};

static void MUX_SetChannel(uint8_t ch)
{
    HAL_GPIO_WritePin(MUX_S0_Port, MUX_S0_Pin, (ch & 1) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MUX_S1_Port, MUX_S1_Pin, (ch & 2) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MUX_S2_Port, MUX_S2_Pin, (ch & 4) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(MUX_S3_Port, MUX_S3_Pin, (ch & 8) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static uint16_t ADC_ReadBlocking(void)
{
    HAL_ADC_Start(&hadc1);
    (void)HAL_ADC_PollForConversion(&hadc1, 2);
    uint16_t v = (uint16_t)HAL_ADC_GetValue(&hadc1);
    HAL_ADC_Stop(&hadc1);
    return v;
}

void MUX_Init(void)
{
    // Không cần TIM2
}

void MUX_UpdateAll(void)
{
    for (uint8_t ch = 0; ch < MUX_CHANNEL_COUNT; ch++)
    {
        MUX_SetChannel(ch);

        // settle ~50–200us (tùy mạch, bạn có thể tăng/giảm)
        for (volatile int i = 0; i < 1200; i++) { __NOP(); }

        // discard 1 sample để tránh dính kênh trước
        (void)ADC_ReadBlocking();

        // average
        uint32_t sum = 0;
        for (int i = 0; i < ADC_SAMPLES; i++)
        {
            sum += ADC_ReadBlocking();
        }
        g_adc_raw[ch] = (uint16_t)(sum / ADC_SAMPLES);
    }
}
