#include "buttons.h"

typedef struct {
    GPIO_TypeDef* port;
    uint16_t      pin;
    uint16_t      bit;
} BtnPin_t;

// ACTIVE-LOW: nhấn = kéo xuống GND
static const BtnPin_t s_btns[] = {
    // 8 subtrim theo bảng anh gửi
    {GPIOC, GPIO_PIN_14, BTN_ST1_BIT}, // CH1-BT1 (PC14)
    {GPIOA, GPIO_PIN_15, BTN_ST2_BIT}, // CH1-BT2 (PA15)
    {GPIOB, GPIO_PIN_3,  BTN_ST3_BIT}, // CH2-BT1 (PB3)
    {GPIOB, GPIO_PIN_4,  BTN_ST4_BIT}, // CH2-BT2 (PB4)
    {GPIOB, GPIO_PIN_5,  BTN_ST5_BIT}, // CH3-BT1 (PB5)
    {GPIOA, GPIO_PIN_1,  BTN_ST6_BIT}, // CH3-BT2 (PA1)
    {GPIOB, GPIO_PIN_0,  BTN_ST7_BIT}, // CH4-BT1 (PB0)
    {GPIOB, GPIO_PIN_1,  BTN_ST8_BIT}, // CH4-BT2 (PB1)

    // Menu
    {GPIOA, GPIO_PIN_8,  BTN_OK_BIT},   // OK (PA8)
    {GPIOB, GPIO_PIN_2,  BTN_BACK_BIT}, // BACK (PB2)
};

#define BTN_COUNT   ((int)(sizeof(s_btns)/sizeof(s_btns[0])))
#define DB_MAX      4   // debounce integrator (tăng nếu loop quá nhanh)

static uint8_t  s_db[BTN_COUNT];
static uint16_t s_stable_mask = 0;

void Buttons_Init(void)
{
    // Bật clock cho các port dùng
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();

    GPIO_InitTypeDef io = {0};
    io.Mode  = GPIO_MODE_INPUT;
    io.Pull  = GPIO_PULLUP;              // đúng theo bảng anh
    io.Speed = GPIO_SPEED_FREQ_LOW;

    for (int i = 0; i < BTN_COUNT; i++) {
        io.Pin = s_btns[i].pin;
        HAL_GPIO_Init(s_btns[i].port, &io);
        s_db[i] = 0;
    }

    s_stable_mask = 0;
}

// Debounce kiểu “integrator”: chống rung + chống nhiễu làm nhảy HOME
uint16_t Buttons_ReadMask(void)
{
    uint16_t mask = 0;

    for (int i = 0; i < BTN_COUNT; i++) {
        GPIO_PinState ps = HAL_GPIO_ReadPin(s_btns[i].port, s_btns[i].pin);
        uint8_t raw_pressed = (ps == GPIO_PIN_RESET) ? 1u : 0u; // active-low

        if (raw_pressed) {
            if (s_db[i] < DB_MAX) s_db[i]++;
        } else {
            if (s_db[i] > 0) s_db[i]--;
        }

        uint8_t stable_pressed = (s_db[i] >= DB_MAX) ? 1u : 0u;
        if (stable_pressed) mask |= s_btns[i].bit;
    }

    s_stable_mask = mask;
    return s_stable_mask;
}
