/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : TX2 - OLED + MUX + EEPROM24C256 + HID Joystick (4 axis + 12 buttons)
  *
  * MUX model:
  *  - g_adc_raw[16] updated by MUX_UpdateAll()
  *
  * Buttons model:
  *  - Buttons_ReadMask() returns bitmask (expect 12-bit used)
  *
  * OLED model:
  *  - OLED_Print6x8(x, y, str) + OLED_Refresh()
  *
  * HID:
  *  - Standard HID class (usbd_hid)
  *  - Report length = 10 bytes
  *    [X(2) Y(2) Z(2) Rx(2) Buttons(12bits + padding)]
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "usb_device.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "mux_adc.h"
#include "buttons.h"
#include "oled_basic.h"
#include "eeprom24.h"
#include "config_store.h"
#include "oled_ui.h"
#include "crsf.h"
#include "radio_link.h"
/* USB HID */
#include "usbd_hid.h"

#include <string.h>
#include <stdio.h>
/* External USB handle */
extern ADC_HandleTypeDef hadc1;
extern I2C_HandleTypeDef hi2c1;
extern USBD_HandleTypeDef hUsbDeviceFS;

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/* ========================== USER CONFIG ========================== */

// ADC config
#define ADC_MAX_COUNTS      (4095u)
#define VREF_VOLTS          (3.30f)

#define VBAT_RTOP_OHM        (100000.0f)   // ví dụ 100k
#define VBAT_RBOT_OHM        (10000.0f)    // ví dụ 10k
#define VBAT_DIV_GAIN        ((VBAT_RTOP_OHM + VBAT_RBOT_OHM)/VBAT_RBOT_OHM)

// Button analog threshold
// Nút kiểu kéo xuống GND qua trở: raw nhỏ => pressed
#define BTN_ADC_PRESSED_TH   (600u)

// Mux settle: discard 1 sample after switching
#define MUX_DISCARD_FIRST    (1)

// Mux oversample
#define MUX_SAMPLES_AVG      (4u)

// USB HID send period (ms)
#define HID_SEND_PERIOD_MS   (5u)

// OLED refresh period (ms)
#define OLED_REFRESH_MS      (30u)

// ===== CRSF / ELRS =====
#define CRSF_SEND_PERIOD_MS  (4u)


#define FAILSAFE_TIMEOUT_MS      200u   // mất input quá 200ms => FS
#define STARTUP_SAFE_HOLD_MS     1500u  // giữ 1.5s để người dùng hạ throttle/arm

#define THR_CH  2
#define ARM_CH  9

#define CRSF_CH_MIN 172u
#define CRSF_CH_MID 992u
#define CRSF_CH_MAX 1811u
/* ========================== MUX GPIO (PB12..PB15) ========================== */
static inline void mux_set_channel(uint8_t ch)
{
    // PB12 S0, PB13 S1, PB14 S2, PB15 S3
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_12, (ch & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, (ch & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_14, (ch & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET);
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, (ch & 0x08) ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

/* ========================== ADC READ HELPERS ========================== */
static inline uint16_t mux_read_channel(uint8_t ch)
{
    return g_adc_raw[ch];
}

static float adc_counts_to_volt(uint16_t raw)
{
    return ((float)raw * VREF_VOLTS) / (float)ADC_MAX_COUNTS;
}

static float vbat_from_mux_c13(uint16_t raw_c13)
{
    float vadc = adc_counts_to_volt(raw_c13);
    return vadc * VBAT_DIV_GAIN;
}

/* ========================== INPUT MAPPING ========================== */

static void fill_ui_input(OLED_UI_Input_t* in)
{
    // ==== 4 trục joystick ====
    in->ax_raw = mux_read_channel(0);  // C0 Aile
    in->ay_raw = mux_read_channel(1);  // C1 Ele
    in->az_raw = mux_read_channel(2);  // C2 Thro
    in->arx_raw= mux_read_channel(3);  // C3 Rud

    // ==== 3 biến trở ====
    in->pot1_raw = mux_read_channel(4); // C4
    in->pot2_raw = mux_read_channel(5); // C5
    in->pot3_raw = mux_read_channel(6); // C6

    // ==== 2 switch 3 vị trí ====
    in->sw3_1_raw = mux_read_channel(7);   // C7  (SW 3pos 1)
    in->sw3_2_raw = mux_read_channel(8);   // C8  (SW 3pos 2)

    // ==== 4 switch 2 vị trí ====
    in->sw2_1_raw = mux_read_channel(9);   // C9  (SW 2pos 1)
    in->sw2_2_raw = mux_read_channel(10);  // C10 (SW 2pos 2)
    in->sw2_3_raw = mux_read_channel(11);  // C11 (SW 2pos 3)
    in->sw2_4_raw = mux_read_channel(12);  // C12 (SW 2pos 4)

    // ==== Battery ====
    uint16_t vb_raw = mux_read_channel(13);
    in->vbat = vbat_from_mux_c13(vb_raw);
    //in->vbat_raw = vb_raw;

    // ==== Buttons for UI (OK/BACK/UP/DOWN) ====
    uint16_t up_raw   = mux_read_channel(14);
    uint16_t down_raw = mux_read_channel(15);

    uint8_t ok_gpio   = (HAL_GPIO_ReadPin(BTN_OK_GPIO_Port,   BTN_OK_Pin)   == GPIO_PIN_RESET) ? 1 : 0;
    uint8_t back_gpio = (HAL_GPIO_ReadPin(BTN_BACK_GPIO_Port, BTN_BACK_Pin) == GPIO_PIN_RESET) ? 1 : 0;

    uint8_t up_pressed   = (up_raw   < BTN_ADC_PRESSED_TH) ? 1 : 0;
    uint8_t down_pressed = (down_raw < BTN_ADC_PRESSED_TH) ? 1 : 0;

    in->btn_mask = 0;
    if (ok_gpio)        in->btn_mask |= (1u << 8);
    if (back_gpio)      in->btn_mask |= (1u << 9);
    if (up_pressed)     in->btn_mask |= (1u << 10);
    if (down_pressed)   in->btn_mask |= (1u << 11);

    // ==== 8 subtrim buttons ====

    if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_14) == GPIO_PIN_RESET) in->btn_mask |= (1u << 0);
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_15) == GPIO_PIN_RESET) in->btn_mask |= (1u << 1);
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3 ) == GPIO_PIN_RESET) in->btn_mask |= (1u << 2);
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_4 ) == GPIO_PIN_RESET) in->btn_mask |= (1u << 3);
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5 ) == GPIO_PIN_RESET) in->btn_mask |= (1u << 4);
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1 ) == GPIO_PIN_RESET) in->btn_mask |= (1u << 5);
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_0 ) == GPIO_PIN_RESET) in->btn_mask |= (1u << 6);
    if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_1 ) == GPIO_PIN_RESET) in->btn_mask |= (1u << 7);

}

/* ========================== USB HID REPORT (TUỲ DESCRIPTOR) ========================== */

   static inline uint16_t u12_to_u16(uint16_t v12)
   {
       // map 0..4095 -> 0..65535 (nhanh, đủ chuẩn)
       return (uint16_t)((v12 << 4) | (v12 >> 8));
   }

   static inline int16_t axis12_to_i16(uint16_t raw, uint16_t ctr)
   {
       // raw: 0..4095 (ADC), ctr: giá trị center đã CALIB lưu trong gConfig.cal_ctr[]
       int32_t d = (int32_t)raw - (int32_t)ctr;   // khoảng -2048..+2047 (xấp xỉ)

       // chặn biên cho an toàn
       if (d < -2048) d = -2048;
       if (d >  2047) d =  2047;

       // scale lên signed 16-bit: -2048*16 = -32768, 2047*16 = 32752
       return (int16_t)(d * 16);
   }

   static inline uint8_t sw2_on_from_raw(uint16_t raw)
   {
       // 2 vị trí: chia đôi ngưỡng
       return (raw > 2048) ? 1u : 0u;
   }

   static inline uint8_t sw3_pos_from_raw(uint16_t raw)
   {
       // 3 vị trí: chia 3 vùng (LOW / MID / HIGH)
       if (raw < 1365) return 2u;   // DOWN
       if (raw > 2730) return 1u;   // UP
       return 0u;                   // MID
   }

#define AXIS_DZ  25   // deadzone 15..50 tùy độ rung

static inline uint16_t clamp12(int32_t v)
{
    if (v < 0) return 0;
    if (v > 4095) return 4095;
    return (uint16_t)v;
}

static inline uint16_t sane_center(uint16_t c)
{
    // Nếu EEPROM lỗi hay lưu bậy, hay gặp: 0xFFFF hoặc 0 hoặc cực trị
    if (c == 0xFFFF || c == 0 || c < 200 || c > 3895) return 2048;
    return c;
}

// idx: 0 AX, 1 AY, 2 AZ, 3 AR
static inline uint16_t apply_center_deadzone(uint16_t raw, int idx)
{
    uint16_t ctr = sane_center(gConfig.cal_ctr[idx]);

    int32_t v = (int32_t)raw - (int32_t)ctr + 2048;
    v = clamp12(v);

    int32_t d = v - 2048;
    if (d > -AXIS_DZ && d < AXIS_DZ) v = 2048;

    return (uint16_t)v;
}

static inline int32_t clamp_i32(int32_t v, int32_t lo, int32_t hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static inline int32_t abs_i32(int32_t v)
{
    return (v < 0) ? -v : v;
}

static inline int16_t axis_raw_to_i16(uint16_t raw, uint16_t ctr_u16, uint8_t invert, uint16_t dz)
{
    uint16_t ctr = sane_center(ctr_u16);

    int32_t d = (int32_t)raw - (int32_t)ctr;     // khoảng ~ -2048..+2047
    if (invert) d = -d;

    // deadzone
    if (abs_i32(d) < (int32_t)dz) d = 0;

    // clamp + scale lên signed 16-bit
    d = clamp_i32(d, -2048, 2047);
    return (int16_t)(d * 16);                    // -32768..+32752
}

static void hid_send_report_4axis(const OLED_UI_Input_t* in)
{
    // Joystick phải bị ngược trái-phải và lên-xuống (ô X/Y)
    // => đảo AX + AY (nếu stick phải của anh nằm ở Z/Rx thì đổi INVERT_AZ/INVERT_AR)
    const uint8_t INVERT_AX = 1;
    const uint8_t INVERT_AY = 1;
    const uint8_t INVERT_AZ = 0;
    const uint8_t INVERT_AR = 0;

    // ===== AXES (signed) =====
    int16_t x  = axis_raw_to_i16(in->ax_raw,  gConfig.cal_ctr[0], INVERT_AX, AXIS_DZ);
    int16_t y  = axis_raw_to_i16(in->ay_raw,  gConfig.cal_ctr[1], INVERT_AY, AXIS_DZ);
    int16_t z  = axis_raw_to_i16(in->az_raw,  gConfig.cal_ctr[2], INVERT_AZ, AXIS_DZ);
    int16_t rx = axis_raw_to_i16(in->arx_raw, gConfig.cal_ctr[3], INVERT_AR, AXIS_DZ);

    // ===== BUTTONS: 20 buttons =====
    uint32_t b20 = (uint32_t)(in->btn_mask & 0x0FFF);

    // 13..16: 4 switch 2 vị trí (ON khi raw > 2048)
    // Nếu ON/OFF bị ngược: đổi dấu so sánh > thành <
    {
        uint8_t sw2_1 = (in->sw2_1_raw > 2048) ? 1u : 0u;
        uint8_t sw2_2 = (in->sw2_2_raw > 2048) ? 1u : 0u;
        uint8_t sw2_3 = (in->sw2_3_raw > 2048) ? 1u : 0u;
        uint8_t sw2_4 = (in->sw2_4_raw > 2048) ? 1u : 0u;

        b20 |= ((uint32_t)sw2_1 << 12);
        b20 |= ((uint32_t)sw2_2 << 13);
        b20 |= ((uint32_t)sw2_3 << 14);
        b20 |= ((uint32_t)sw2_4 << 15);
    }

    // 17..20: 2 switch 3 vị trí (UP/DOWN)
    {
        uint8_t p31 = sw3_pos_from_raw(in->sw3_1_raw); // 0 mid, 1 up, 2 down
        uint8_t p32 = sw3_pos_from_raw(in->sw3_2_raw);

        b20 |= ((uint32_t)(p31 == 1u) << 16); // SW3_1_UP
        b20 |= ((uint32_t)(p31 == 2u) << 17); // SW3_1_DOWN
        b20 |= ((uint32_t)(p32 == 1u) << 18); // SW3_2_UP
        b20 |= ((uint32_t)(p32 == 2u) << 19); // SW3_2_DOWN
    }

    // ===== PACK REPORT (11 bytes) =====
    // 8 bytes axes + 3 bytes buttons(20bit + padding)
    uint8_t rep[11];

    rep[0] = (uint8_t)(x);   rep[1] = (uint8_t)(x >> 8);
    rep[2] = (uint8_t)(y);   rep[3] = (uint8_t)(y >> 8);
    rep[4] = (uint8_t)(z);   rep[5] = (uint8_t)(z >> 8);
    rep[6] = (uint8_t)(rx);  rep[7] = (uint8_t)(rx >> 8);

    rep[8]  = (uint8_t)(b20 & 0xFF);
    rep[9]  = (uint8_t)((b20 >> 8) & 0xFF);
    rep[10] = (uint8_t)((b20 >> 16) & 0xFF);

    if (hUsbDeviceFS.dev_state == USBD_STATE_CONFIGURED) {
        (void)USBD_HID_SendReport(&hUsbDeviceFS, rep, sizeof(rep));
    }
}

/* ========================== BUZZER (active buzzer) ========================== */

//   RESET = ON, SET = OFF
#define BUZZER_ON()   HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET)
#define BUZZER_OFF()  HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_SET)

static void buzzer_beep(uint16_t on_ms, uint16_t off_ms)
{
    BUZZER_ON();
    HAL_Delay(on_ms);
    BUZZER_OFF();
    if (off_ms) HAL_Delay(off_ms);
}

static void buzzer_trill(uint8_t times, uint16_t on_ms, uint16_t off_ms)
{
    for (uint8_t i = 0; i < times; i++) {
        buzzer_beep(on_ms, off_ms);
    }
}

// “Boot tune” ~ 2 giây: nhịp dễ nghe + đoạn trill cuối
static void buzzer_boot_tune_2s(void)
{
    BUZZER_OFF(); // đảm bảo tắt trước

    // Intro: bip-bip (nhanh), bip dài (xác nhận boot)
    buzzer_beep(70, 60);
    buzzer_beep(70, 120);
    buzzer_beep(180, 160);

    // Mid: “double tap” + nghỉ
    buzzer_beep(90, 50);
    buzzer_beep(90, 200);

    // Ending: trill nhanh kiểu “ready”
    buzzer_trill(10, 30, 20);  // 10 lần * (30+20) = 500ms

    // Kết thúc: 1 tiếng chốt
    buzzer_beep(220, 0);

    BUZZER_OFF();
}

static uint8_t g_uart2_rx_byte;
static uint32_t g_last_input_ms = 0;


static uint32_t g_boot_ms = 0;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  g_boot_ms = HAL_GetTick();
  buzzer_boot_tune_2s();
  MX_DMA_Init();
  MX_ADC1_Init();
  MX_I2C1_Init();
  MX_USB_DEVICE_Init();
  MX_TIM2_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  Buttons_Init();
  OLED_Init();
     OLED_Clear();
     OLED_Print6x8(0,0,"TX BOOT...");
     OLED_Refresh();

     OLED_UI_Init();

     OLED_UI_Input_t ui_in;
     memset(&ui_in, 0, sizeof(ui_in));

     uint32_t t_hid  = HAL_GetTick();
     uint32_t t_oled = HAL_GetTick();
     uint32_t t_crsf = HAL_GetTick();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
     while (1)
      {
        /* USER CODE END WHILE */
          uint32_t now = HAL_GetTick();
    	  // Read all controls

    	  MUX_UpdateAll();
    	         fill_ui_input(&ui_in);
    	         g_last_input_ms = now;
    	         // USB HID periodic send

    	         if ((now - t_hid) >= HID_SEND_PERIOD_MS) {
    	             t_hid = now;
    	             hid_send_report_4axis(&ui_in);
    	         }
    	         // CRSF
    	         if ((now - t_crsf) >= CRSF_SEND_PERIOD_MS) {
    	             t_crsf = now;

    	             uint16_t ch[16] = {
    	                 CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID,
    	                 CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID,
    	                 CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID,
    	                 CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID,CRSF_CH_MID
    	             };

    	             // CH1..CH16 đúng theo C0..C15
    	             ch[0] = crsf_map_adc12_to_channel(ui_in.ax_raw);   // C0  CH1 Aile
    	             ch[1] = crsf_map_adc12_to_channel(ui_in.ay_raw);   // C1  CH2 Ele
    	             ch[2] = crsf_map_adc12_to_channel(ui_in.az_raw);   // C2  CH3 Thro
    	             ch[3] = crsf_map_adc12_to_channel(ui_in.arx_raw);  // C3  CH4 Rud

    	             ch[4] = crsf_map_adc12_to_channel(ui_in.pot1_raw); // C4  CH5 Pot1
    	             ch[5] = crsf_map_adc12_to_channel(ui_in.pot2_raw); // C5  CH6 Pot2
    	             ch[6] = crsf_map_adc12_to_channel(ui_in.pot3_raw); // C6  CH7 Pot3

    	             ch[7] = crsf_sw3pos_to_channel(sw3_pos_from_raw(ui_in.sw3_1_raw)); // C7  CH8  SW3pos1
    	             ch[8] = crsf_sw3pos_to_channel(sw3_pos_from_raw(ui_in.sw3_2_raw)); // C8  CH9  SW3pos2

    	             ch[9]  = crsf_sw2_to_channel(ui_in.sw2_1_raw);  // C9  CH10 ARM
    	             ch[10] = crsf_sw2_to_channel(ui_in.sw2_2_raw);  // C10 CH11 RTL
    	             ch[11] = crsf_sw2_to_channel(ui_in.sw2_3_raw);  // C11 CH12 LOITER
    	             ch[12] = crsf_sw2_to_channel(ui_in.sw2_4_raw);  // C12 CH13 BEEP

    	             // C13: đo áp —
    	             ch[13] = CRSF_CH_MID;   // CH14 giữ ổn định, không gây nhiễu

    	             // C14/C15: Menu UP/DOWN (momentary) — map kiểu nhấn=MAX, thả=MIN
    	             uint8_t up_pressed   = ( (ui_in.btn_mask & (1u<<10)) != 0 );
    	             uint8_t down_pressed = ( (ui_in.btn_mask & (1u<<11)) != 0 );

    	             ch[14] = up_pressed   ? CRSF_CH_MAX : CRSF_CH_MIN;  // C14 CH15 Menu UP
    	             ch[15] = down_pressed ? CRSF_CH_MAX : CRSF_CH_MIN;  // C15 CH16 Menu DOWN

    	             // --- SAFETY: clamp channel range (phòng map lỗi)
    	             for (int i = 0; i < 16; i++) {
    	                 if (ch[i] < CRSF_CH_MIN) ch[i] = CRSF_CH_MIN;
    	                 else if (ch[i] > CRSF_CH_MAX) ch[i] = CRSF_CH_MAX;
    	             }

    	             // --- SAFETY: Startup gate (1.5s đầu luôn ép throttle=min, arm=off)
    	             if ((uint32_t)(now - g_boot_ms) < STARTUP_SAFE_HOLD_MS) {
    	                 ch[2] = CRSF_CH_MIN;  // throttle = CH3 (index 2)
    	                 ch[9] = CRSF_CH_MIN;  // ARM = CH10 (index 9) theo code bạn comment
    	             } else {
    	                 // Sau boot: nếu throttle chưa về min hoặc arm đang ON thì vẫn chặn
    	                 if (ch[2] > (CRSF_CH_MIN + 30) || ch[9] > (CRSF_CH_MIN + 30)) {
    	                     ch[2] = CRSF_CH_MIN;
    	                     ch[9] = CRSF_CH_MIN;
    	                 }
    	             }

    	             // --- SAFETY: failsafe theo input stale
    	             radio_link_apply_failsafe(ch, now, g_last_input_ms, FAILSAFE_TIMEOUT_MS);

    	             // Send
    	             radio_link_send_channels(ch);
    	         }


    	         // OLED UI refresh
    	         if ((now - t_oled) >= OLED_REFRESH_MS) {
    	             t_oled = now;
    	             radio_link_stats_t st = radio_link_get_stats();
    	             ui_in.lq = st.uplink_lq_percent;
    	             ui_in.rssi_dbm = st.uplink_rssi1_dbm_neg; // nó là “-dBm” rồi
    	             ui_in.snr_db = st.uplink_snr_db;

    	             ui_in.link_age_ms = now - st.last_update_ms;
    	             OLED_UI_Render(&ui_in);
    	         }

    	         // Small idle delay
    	         HAL_Delay(1);

        /* USER CODE BEGIN 3 */
      }
      /* USER CODE END 3 */
    }

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        uint32_t now = HAL_GetTick();
        radio_link_on_rx_byte(g_uart2_rx_byte, now);

        // nhận tiếp byte sau
        HAL_UART_Receive_IT(&huart2, &g_uart2_rx_byte, 1);
    }
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART2) {
        // recover các lỗi kiểu ORE/FE để không “đứng RX”
        __HAL_UART_CLEAR_OREFLAG(huart);
        __HAL_UART_CLEAR_FEFLAG(huart);
        __HAL_UART_CLEAR_NEFLAG(huart);
        __HAL_UART_CLEAR_PEFLAG(huart);

        HAL_UART_Receive_IT(&huart2, &g_uart2_rx_byte, 1);
    }
}

static inline uint16_t clamp_u16(uint16_t v, uint16_t lo, uint16_t hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
