#include "eeprom24.h"
#include "i2c.h"

#define EEPROM_ADDR (0x50 << 1)
#define PAGE_SIZE 64
#define I2C_TIMEOUT 20

static HAL_StatusTypeDef EEPROM_WaitReady(void)
{
    uint32_t tick = HAL_GetTick();
    while (HAL_GetTick() - tick < 20)
        if (HAL_I2C_IsDeviceReady(&hi2c1, EEPROM_ADDR, 1, I2C_TIMEOUT) == HAL_OK)
            return HAL_OK;
    return HAL_TIMEOUT;
}

HAL_StatusTypeDef EEPROM24_WritePage(uint16_t memAddr, uint8_t* data, uint16_t len)
{
    uint8_t buf[PAGE_SIZE + 2];
    buf[0] = memAddr >> 8;
    buf[1] = memAddr & 0xFF;

    for (uint16_t i = 0; i < len; i++)
        buf[2 + i] = data[i];

    HAL_StatusTypeDef status =
        HAL_I2C_Master_Transmit(&hi2c1, EEPROM_ADDR, buf, len + 2, I2C_TIMEOUT);

    if (status != HAL_OK) return status;

    return EEPROM_WaitReady();
}

HAL_StatusTypeDef EEPROM24_Write(uint16_t memAddr, uint8_t* data, uint16_t len)
{
    uint16_t offset = 0;

    while (offset < len)
    {
        uint16_t pageOffset = memAddr % PAGE_SIZE;
        uint16_t space = PAGE_SIZE - pageOffset;
        uint16_t writeLen = (len - offset < space) ? (len - offset) : space;

        HAL_StatusTypeDef r = EEPROM24_WritePage(memAddr, &data[offset], writeLen);
        if (r != HAL_OK) return r;

        memAddr += writeLen;
        offset  += writeLen;
    }
    return HAL_OK;
}

HAL_StatusTypeDef EEPROM24_Read(uint16_t memAddr, uint8_t* data, uint16_t len)
{
    uint8_t addr[2] = {memAddr >> 8, memAddr & 0xFF};

    if (HAL_I2C_Master_Transmit(&hi2c1, EEPROM_ADDR, addr, 2, I2C_TIMEOUT) != HAL_OK)
        return HAL_ERROR;

    if (HAL_I2C_Master_Receive(&hi2c1, EEPROM_ADDR, data, len, I2C_TIMEOUT) != HAL_OK)
        return HAL_ERROR;

    return HAL_OK;
}

HAL_StatusTypeDef EEPROM24_Init(uint8_t addr)
{
    return EEPROM_WaitReady();
}
