#include "radio_link.h"
#include "crsf.h"
#include <string.h>

static UART_HandleTypeDef* s_huart = 0;
static crsf_parser_t s_parser;

static volatile radio_link_stats_t s_stats;
static volatile uint32_t s_now_ms = 0;
static void on_crsf_frame(const crsf_frame_t* f, void* user)
{
    (void)user;

    if (!f) return;
    if (f->type != CRSF_TYPE_LINK_STATISTICS) return;

    // theo mô tả payload 0x14 (tối thiểu 10 bytes)
    if (f->payload_len < 10) return;

    // payload layout (theo ExpressLRS crsf_protocol.h)
    // 0: uplink rssi1 (dBm*-1)
    // 1: uplink rssi2 (dBm*-1)
    // 2: uplink LQ %
    // 3: uplink SNR (dB, int8)
    // 4: active antenna
    // 5: rf mode
    // 6: tx power
    // 7: downlink rssi (dBm*-1)
    // 8: downlink LQ %
    // 9: downlink SNR (int8)
    const uint8_t* p = f->payload;

    s_stats.uplink_rssi1_dbm_neg = (int8_t)p[0];
    s_stats.uplink_rssi2_dbm_neg = (int8_t)p[1];
    s_stats.uplink_lq_percent    = p[2];
    s_stats.uplink_snr_db        = (int8_t)p[3];

    s_stats.rf_mode              = p[5];
    s_stats.tx_power             = p[6];

    s_stats.downlink_rssi_dbm_neg = (int8_t)p[7];
    s_stats.downlink_lq_percent   = p[8];
    s_stats.downlink_snr_db       = (int8_t)p[9];
    s_stats.last_update_ms = s_now_ms;
}

void radio_link_init(UART_HandleTypeDef* huart, uint32_t now_ms)
{
    s_huart = huart;
    memset((void*)&s_stats, 0, sizeof(s_stats));
    s_stats.last_update_ms = now_ms;

    crsf_parser_init(&s_parser, on_crsf_frame, 0);
}

void radio_link_send_channels(const uint16_t ch16[16])
{
    if (!s_huart || !ch16) return;

    uint8_t frame[32];
    size_t n = crsf_build_rc_channels_frame(frame, sizeof(frame),
                                           CRSF_ADDR_CRSF_TRANSMITTER, // giống bạn đang dùng
                                           ch16);
    if (n) {
        HAL_UART_Transmit(s_huart, frame, (uint16_t)n, 2);
    }
}

void radio_link_on_rx_byte(uint8_t b, uint32_t now_ms)
{
    s_now_ms = now_ms;
    crsf_parser_feed(&s_parser, b);
}

radio_link_stats_t radio_link_get_stats(void)
{
    return s_stats; // copy struct
}

void radio_link_apply_failsafe(uint16_t ch16[16],
                               uint32_t now_ms,
                               uint32_t last_input_ms,
                               uint32_t timeout_ms)
{
    if (!ch16) return;
    if ((uint32_t)(now_ms - last_input_ms) <= timeout_ms) return;

    // FAILSAFE: throttle min + arm off (bạn chỉnh đúng kênh arm của bạn)
    ch16[2] = CRSF_CH_MIN; // throttle (CH3)
    ch16[9] = CRSF_CH_MIN; // ARM = CH10 (index 9)
}
