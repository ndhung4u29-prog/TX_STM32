#include "config_store.h"
#include "eeprom24.h"
#include <string.h>

#define CONFIG_ADDR 0x0000
#define CONFIG_MAGIC  0xC0DF

Config_t gConfig;

void Config_Load(void)
{
    uint8_t buf[sizeof(Config_t)];

    if (EEPROM24_Read(CONFIG_ADDR, buf, sizeof(buf)) != HAL_OK)
    {
        Config_ResetDefaults();
        Config_Save();
        return;
    }

    memcpy(&gConfig, buf, sizeof(buf));

    if (gConfig.magic != CONFIG_MAGIC)
    {
        Config_ResetDefaults();
        Config_Save();
    }
}

void Config_Save(void)
{
    gConfig.magic = CONFIG_MAGIC;
    EEPROM24_Write(CONFIG_ADDR, (uint8_t*)&gConfig, sizeof(Config_t));
}

void Config_ResetDefaults(void)
{
	   memset(&gConfig, 0, sizeof(gConfig));
	    gConfig.magic = CONFIG_MAGIC;

	    for (int i = 0; i < 7; i++) {
	        gConfig.cal_min[i] = 0;
	        gConfig.cal_max[i] = 4095;
	        gConfig.cal_ctr[i] = 2048;
	    }
}
