#include "oled_basic.h"
#include "i2c.h"
#include <string.h>
#include <stdio.h>
#include "font6x8.h"
static uint8_t oled_buffer[128 * 8];

// Extern font table (0x20-0x7F) từ font6x8.c
extern const uint8_t Font6x8[][6];

static void OLED_WriteCmd(uint8_t cmd)
{
    HAL_I2C_Mem_Write(&hi2c1, OLED_ADDR, 0x00, 1, &cmd, 1, 10);
}

static void OLED_WriteData(uint8_t *data, uint16_t size)
{
    HAL_I2C_Mem_Write(&hi2c1, OLED_ADDR, 0x40, 1, data, size, 10);
}

void OLED_Init(void)
{
    HAL_Delay(100);

    OLED_WriteCmd(0xAE);
    OLED_WriteCmd(0x20); OLED_WriteCmd(0x00);
    OLED_WriteCmd(0x40);
    OLED_WriteCmd(0xA1);
    OLED_WriteCmd(0xC8);
    OLED_WriteCmd(0x81); OLED_WriteCmd(0x7F);
    OLED_WriteCmd(0xA4);
    OLED_WriteCmd(0xA6);
    OLED_WriteCmd(0xAF);

    OLED_Clear();
    OLED_Refresh();
}

void OLED_Clear(void)
{
    memset(oled_buffer, 0, sizeof(oled_buffer));
}

void OLED_Refresh(void)
{
    for (uint8_t page = 0; page < 8; page++) {
        OLED_WriteCmd(0xB0 + page);
        OLED_WriteCmd(0x00);
        OLED_WriteCmd(0x10);
        OLED_WriteData(&oled_buffer[page * 128], 128);
    }
}

void OLED_DrawPixel(uint8_t x, uint8_t y, uint8_t color)
{
    if (x >= 128 || y >= 64) return;
    uint16_t idx = (y / 8) * 128 + x;
    uint8_t  bit = 1U << (y & 7);
    if (color) oled_buffer[idx] |= bit;
    else       oled_buffer[idx] &= (uint8_t)~bit;
}

void OLED_DrawChar6x8(uint8_t x, uint8_t y, char c)
{
    if (c < 32 || c > 126) c = '?';
    for (uint8_t i = 0; i < 6; i++)
        oled_buffer[(y / 8) * 128 + x + i] = Font6x8[c - 32][i];
}

void OLED_Print6x8(uint8_t x, uint8_t y, const char *str)
{
    while (*str) {
        OLED_DrawChar6x8(x, y, *str++);
        x += 6;
        if (x > 122) break;
    }
}

void OLED_DrawFrame(uint8_t x, uint8_t y, uint8_t w, uint8_t h)
{
    for (uint8_t i = 0; i < w; i++) {
        OLED_DrawPixel(x + i, y, 1);
        OLED_DrawPixel(x + i, y + h - 1, 1);
    }
    for (uint8_t i = 0; i < h; i++) {
        OLED_DrawPixel(x, y + i, 1);
        OLED_DrawPixel(x + w - 1, y + i, 1);
    }
}

void OLED_DrawBar(uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t percent)
{
    uint8_t fill = (percent * w) / 100;

    for (uint8_t yy = 0; yy < h; yy++) {
        for (uint8_t xx = 0; xx < w; xx++) {
            OLED_DrawPixel(x + xx, y + yy, (xx <= fill));
        }
    }
}
