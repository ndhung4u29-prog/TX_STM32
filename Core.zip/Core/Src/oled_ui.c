#include "oled_ui.h"
#include "oled_basic.h"
#include "config_store.h"
#include <stdio.h>
#include <string.h>
#include <stdint.h>

// ================= BUTTON MAP =================
#define BTN_OK_BIT    (1u << 8)
#define BTN_BACK_BIT  (1u << 9)
#define BTN_UP_BIT    (1u << 10)
#define BTN_DOWN_BIT  (1u << 11)
#define BTN_NAV_MASK (BTN_OK_BIT | BTN_BACK_BIT | BTN_UP_BIT | BTN_DOWN_BIT)

// ================= CALIB INDEX =================
// 0 AX(Aile/C0), 1 AY(Ele/C1), 2 AZ(Thro/C2), 3 AR(Rud/C3), 4 P1, 5 P2, 6 P3
#define CAL_AX 0
#define CAL_AY 1
#define CAL_AZ 2
#define CAL_AR 3
#define CAL_P1 4
#define CAL_P2 5
#define CAL_P3 6

// ================= HOME LAYOUT =================
#define HOME_BOX  30       // nhỏ hơn để chừa chỗ chữ + pin
#define HOME_Y0   14       // canh cho đẹp

// ================= SWITCH THRESHOLDS (tune nếu cần) =================
#define SW2_TH          (2048u)
#define SW3_TH_LOW      (1024u)
#define SW3_TH_HIGH     (2563u)


// ================= UTILS =================
static uint16_t clamp_u16(uint16_t v, uint16_t lo, uint16_t hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

static uint8_t pct_from_raw(uint16_t raw)
{
    return (uint8_t)((raw * 100u) / 4095u);
}

static int decode_2pos(uint16_t raw)
{
    return (raw > SW2_TH) ? 1 : 0;
}

static int decode_3pos(uint16_t raw)
{
    if (raw < SW3_TH_LOW) return 0;      // LOW
    if (raw < SW3_TH_HIGH) return 1;     // MID
    return 2;                             // HIGH
}

static const char* s3_text(int s)
{
    return (s == 0) ? "LOW" : (s == 1) ? "MID" : "HIGH";
}

// 8 nút subtrim: mặc định lấy bit 0..7 trong btn_mask
static int subtrim_bit(uint16_t mask, int idx1_8)
{
    return (mask >> (idx1_8 - 1)) & 1;
}

// ================= CALIB STATE =================
typedef enum { CAL_IDLE=0, CAL_RECORDING, CAL_CENTER, CAL_SAVED } calib_state_t;
static calib_state_t cal_state = CAL_IDLE;

static uint16_t cal_min_w[7];
static uint16_t cal_max_w[7];
static uint16_t cal_ctr_w[7];

static void calib_reset_working(void)
{
    for (int i = 0; i < 7; i++) {
        cal_min_w[i] = 4095;
        cal_max_w[i] = 0;
        cal_ctr_w[i] = 2048;
    }
}

static void calib_feed(uint16_t v, int idx)
{
    if (v < cal_min_w[idx]) cal_min_w[idx] = v;
    if (v > cal_max_w[idx]) cal_max_w[idx] = v;
}

static int norm_0_1000(uint16_t raw, int cal_idx)
{
    uint16_t mn = gConfig.cal_min[cal_idx];
    uint16_t mx = gConfig.cal_max[cal_idx];
    if (mx <= mn + 10) return 500;

    raw = clamp_u16(raw, mn, mx);
    return (int)(((uint32_t)(raw - mn) * 1000u) / (mx - mn));
}

// ================= DRAW PRIMITIVES =================
static void draw_dot3(int x, int y)
{
    for (int dy = -1; dy <= 1; dy++)
        for (int dx = -1; dx <= 1; dx++)
            OLED_DrawPixel(x + dx, y + dy, 1);
}

// vẽ icon pin nhỏ (khung + fill theo %)
static void draw_battery_icon(int x, int y, int w, int h, int pct)
{
    if (pct < 0) pct = 0;
    if (pct > 100) pct = 100;

    // khung chính
    OLED_DrawFrame(x, y, w, h);
    // đầu pin
    OLED_DrawFrame(x + w, y + (h/3), 2, h - 2*(h/3));

    // fill bên trong
    int inner_w = w - 2;
    int inner_h = h - 2;
    int fill_w = (inner_w * pct) / 100;

    for (int yy = 0; yy < inner_h; yy++) {
        for (int xx = 0; xx < fill_w; xx++) {
            OLED_DrawPixel(x + 1 + xx, y + 1 + yy, 1);
        }
    }
}

// ================= JOYSTICK BOX =================
static void draw_joy_box_fixed(
    int x, int y, int size,
    uint16_t raw_x, uint16_t raw_y,
    int cal_x, int cal_y,
    int swap_xy, int inv_x, int inv_y
){
    OLED_DrawFrame(x, y, size, size);

    int nx = norm_0_1000(raw_x, cal_x);
    int ny = norm_0_1000(raw_y, cal_y);

    if (swap_xy) { int t = nx; nx = ny; ny = t; }
    if (inv_x) nx = 1000 - nx;
    if (inv_y) ny = 1000 - ny;

    int inner = size - 2;
    int px = x + 1 + (nx * (inner - 1)) / 1000;
    int py = y + 1 + ((1000 - ny) * (inner - 1)) / 1000;

    draw_dot3(px, py);
    OLED_DrawPixel(x + size/2, y + size/2, 1);
}

// ================= UI STATE =================
typedef enum {
    UI_HOME = 0,
    UI_MENU,
    UI_AXES,
    UI_IO,
    UI_SUBTRIM,
    UI_CALIB,
    UI_ABOUT
} ui_screen_t;

static ui_screen_t ui_screen = UI_HOME;
static uint8_t menu_idx = 0;
static uint16_t prev_btn = 0;

// IO subpage: 0=POT, 1=SW
static uint8_t io_page = 0;

// ================= SCREENS =================

// HOME: GIỮ NGUYÊN mapping 2 ô joystick như anh đang dùng
static void draw_home(const OLED_UI_Input_t* in)
{
    char line[24];
    OLED_Clear();

    // Header voltage (ngắn gọn, font dễ hỗ trợ)
    int mv = (int)(in->vbat * 1000.0f + 0.5f);  // vẫn dùng float nội bộ, nhưng không printf float
    snprintf(line, sizeof(line), "TX2 %d.%02dV", mv/1000, (mv%1000)/10);
    OLED_Print6x8(0, 0, line);

    // battery icon (giả định 3.2V->0%, 4.2V->100%)
    int bpct = (int)(((in->vbat - 3.2f) * 100.0f) / (4.2f - 3.2f));
    draw_battery_icon(98, 0, 24, 8, bpct);
    // Telemetry line: phải ngắn để không chạm vùng pin (x>=98)
    char tline[24];
    snprintf(tline, sizeof(tline), "LQ%3u R%3d S%2d",
             (unsigned)in->lq,
             -(int)in->rssi_dbm,   // nếu in->rssi_dbm đang lưu kiểu “-dBm” (vd 65 => -65dBm) thì hiển thị âm cho dễ hiểu
             (int)in->snr_db);
    OLED_Print6x8(0, 8, tline);

    const int box = HOME_BOX;
    const int y0  = HOME_Y0;

    // ===== GIỮ NGUYÊN MAPPING (đúng thực tế của anh) =====
    // LEFT box
    draw_joy_box_fixed(
        2, y0, box,
        in->arx_raw,   // C3
        in->az_raw,    // C2
        CAL_AR, CAL_AZ,
        0,  // swap_xy
        1,  // invert_x
        0   // invert_y
    );

    // RIGHT box
    draw_joy_box_fixed(
        128 - box - 2, y0, box,
        in->ax_raw,   // C0
        in->ay_raw,   // C1
        CAL_AX, CAL_AY,
        0,  // swap_xy
        1,  // invert_x
        0   // invert_y
    );
    // =====================================================

    OLED_Print6x8(18, y0 + box + 2, "L");
    OLED_Print6x8(128 - box - 2 + 16, y0 + box + 2, "R");

    OLED_Print6x8(0, 56, "OK:MENU  BACK:HOME");
    OLED_Refresh();
}

static void draw_menu(void)
{
    OLED_Clear();
    OLED_Print6x8(0, 0, "MENU");

    const char* items[] = {"HOME","AXES","IO","SUBTRIM","CALIB","ABOUT"};
    const int n = 6;

    char buf[24];
    for (int i = 0; i < n; i++) {
        snprintf(buf, sizeof(buf), "%s%s", (i == menu_idx) ? ">>" : "  ", items[i]);
        OLED_Print6x8(0, 8 + i * 8, buf);
    }

    OLED_Print6x8(0, 56, "OK:SEL  BACK:EXIT");
    OLED_Refresh();
}

static void draw_axes(const OLED_UI_Input_t* in)
{
    char buf[24];
    OLED_Clear();
    OLED_Print6x8(0, 0, "AXES C0..C3");

    snprintf(buf, sizeof(buf), "C0 AX:%4u", in->ax_raw);
    OLED_Print6x8(0, 8, buf);
    snprintf(buf, sizeof(buf), "C1 AY:%4u", in->ay_raw);
    OLED_Print6x8(0, 16, buf);
    snprintf(buf, sizeof(buf), "C2 AZ:%4u", in->az_raw);
    OLED_Print6x8(0, 24, buf);
    snprintf(buf, sizeof(buf), "C3 AR:%4u", in->arx_raw);
    OLED_Print6x8(0, 32, buf);

    OLED_Print6x8(0, 56, "BACK:HOME");
    OLED_Refresh();
}

static void draw_io(const OLED_UI_Input_t* in)
{
    char buf[24];
    OLED_Clear();
    OLED_Print6x8(0, 0, "IO");

    if (io_page == 0) {
        // PAGE 0: POT
        OLED_Print6x8(90, 0, "POT");

        snprintf(buf, sizeof(buf), "P1:%4u %3u%%", in->pot1_raw, pct_from_raw(in->pot1_raw));
        OLED_Print6x8(0, 8, buf);
        snprintf(buf, sizeof(buf), "P2:%4u %3u%%", in->pot2_raw, pct_from_raw(in->pot2_raw));
        OLED_Print6x8(0, 16, buf);
        snprintf(buf, sizeof(buf), "P3:%4u %3u%%", in->pot3_raw, pct_from_raw(in->pot3_raw));
        OLED_Print6x8(0, 24, buf);

        OLED_Print6x8(0, 40, "OK:SW PAGE");
        OLED_Print6x8(0, 56, "BACK:HOME");
    } else {
        // PAGE 1: SWITCHES
    	OLED_Print6x8(96, 0, "SW");

    	char buf[24];

    	// 4 switch 2 vị trí -> SW1..SW4
    	snprintf(buf, sizeof(buf), "SW1:%d %4u", decode_2pos(in->sw2_1_raw), in->sw2_1_raw);
    	OLED_Print6x8(0, 8, buf);

    	snprintf(buf, sizeof(buf), "SW2:%d %4u", decode_2pos(in->sw2_2_raw), in->sw2_2_raw);
    	OLED_Print6x8(0, 16, buf);

    	snprintf(buf, sizeof(buf), "SW3:%d %4u", decode_2pos(in->sw2_3_raw), in->sw2_3_raw);
    	OLED_Print6x8(0, 24, buf);

    	snprintf(buf, sizeof(buf), "SW4:%d %4u", decode_2pos(in->sw2_4_raw), in->sw2_4_raw);
    	OLED_Print6x8(0, 32, buf);

    	// 2 switch 3 vị trí -> SW5..SW6
    	snprintf(buf, sizeof(buf), "SW5:%s %4u", s3_text(decode_3pos(in->sw3_1_raw)), in->sw3_1_raw);
    	OLED_Print6x8(0, 40, buf);

    	snprintf(buf, sizeof(buf), "SW6:%s %4u", s3_text(decode_3pos(in->sw3_2_raw)), in->sw3_2_raw);
    	OLED_Print6x8(0, 48, buf);

    	OLED_Print6x8(0, 56, "OK:POT  BACK:HOME");
    }

    OLED_Refresh();
}

static void draw_subtrim(const OLED_UI_Input_t* in)
{
    OLED_Clear();
    OLED_Print6x8(0, 0, "SUBTRIM 8");

    // 2 cột để không tràn ST4/ST8
    char b[12];

    // y=16
    snprintf(b, sizeof(b), "ST1:%d", subtrim_bit(in->btn_mask, 1));
    OLED_Print6x8(0, 16, b);
    snprintf(b, sizeof(b), "ST2:%d", subtrim_bit(in->btn_mask, 2));
    OLED_Print6x8(64, 16, b);

    // y=24
    snprintf(b, sizeof(b), "ST3:%d", subtrim_bit(in->btn_mask, 3));
    OLED_Print6x8(0, 24, b);
    snprintf(b, sizeof(b), "ST4:%d", subtrim_bit(in->btn_mask, 4));
    OLED_Print6x8(64, 24, b);

    // y=32
    snprintf(b, sizeof(b), "ST5:%d", subtrim_bit(in->btn_mask, 5));
    OLED_Print6x8(0, 32, b);
    snprintf(b, sizeof(b), "ST6:%d", subtrim_bit(in->btn_mask, 6));
    OLED_Print6x8(64, 32, b);

    // y=40
    snprintf(b, sizeof(b), "ST7:%d", subtrim_bit(in->btn_mask, 7));
    OLED_Print6x8(0, 40, b);
    snprintf(b, sizeof(b), "ST8:%d", subtrim_bit(in->btn_mask, 8));
    OLED_Print6x8(64, 40, b);

    // Optional: show mask hex để debug
    char buf[24];
    snprintf(buf, sizeof(buf), "MASK:%04X", in->btn_mask);
    OLED_Print6x8(0, 48, buf);

    OLED_Print6x8(0, 56, "BACK:HOME");
    OLED_Refresh();
}

static void draw_calib(const OLED_UI_Input_t* in)
{
    char buf[24];
    OLED_Clear();
    OLED_Print6x8(0, 0, "CALIB");

    // NOTE: dùng chữ IN HOA + ngắn -> tránh font bị vỡ
    if (cal_state == CAL_IDLE) {
        OLED_Print6x8(0, 8,  "OK:START");
        OLED_Print6x8(0, 16, "MOVE ALL ENDS");
        OLED_Print6x8(0, 24, "OK:NEXT");
        OLED_Print6x8(0, 56, "BACK:HOME");
    }
    else if (cal_state == CAL_RECORDING) {
        calib_feed(in->ax_raw, CAL_AX);
        calib_feed(in->ay_raw, CAL_AY);
        calib_feed(in->az_raw, CAL_AZ);
        calib_feed(in->arx_raw, CAL_AR);
        calib_feed(in->pot1_raw, CAL_P1);
        calib_feed(in->pot2_raw, CAL_P2);
        calib_feed(in->pot3_raw, CAL_P3);

        OLED_Print6x8(0, 8,  "REC...MOVE");
        OLED_Print6x8(0, 16, "OK:NEXT CTR");
        snprintf(buf, sizeof(buf), "AX %u-%u", cal_min_w[CAL_AX], cal_max_w[CAL_AX]);
        OLED_Print6x8(0, 32, buf);
        snprintf(buf, sizeof(buf), "AY %u-%u", cal_min_w[CAL_AY], cal_max_w[CAL_AY]);
        OLED_Print6x8(0, 40, buf);
        OLED_Print6x8(0, 56, "BACK:CANCEL");
    }
    else if (cal_state == CAL_CENTER) {
        OLED_Print6x8(0, 8,  "CENTER STICKS");
        OLED_Print6x8(0, 16, "OK:SAVE");
        snprintf(buf, sizeof(buf), "AX:%u AY:%u", in->ax_raw, in->ay_raw);
        OLED_Print6x8(0, 32, buf);
        OLED_Print6x8(0, 56, "BACK:CANCEL");
    }
    else { // CAL_SAVED
        OLED_Print6x8(0, 24, "SAVED!");
        OLED_Print6x8(0, 56, "BACK:HOME");
    }

    OLED_Refresh();
}

static void draw_about(void)
{
    OLED_Clear();
    OLED_Print6x8(0, 0, "ABOUT");
    OLED_Print6x8(0, 16, "TX2 OLED UI");
    OLED_Print6x8(0, 24, "HOME:JOY+VBAT");
    OLED_Print6x8(0, 32, "IO/SUB/CALIB");
    OLED_Print6x8(0, 56, "BACK:HOME");
    OLED_Refresh();
}

// ================= PUBLIC API =================
void OLED_UI_Init(void)
{
    Config_Load();
    ui_screen = UI_HOME;
    menu_idx = 0;
    prev_btn = 0;
    io_page = 0;
    cal_state = CAL_IDLE;
    calib_reset_working();
}

void OLED_UI_Render(const OLED_UI_Input_t* in)
{
    if (!in) return;

    // ================= NAV-ONLY DEBOUNCE =================
    // Chỉ lọc OK/BACK/UP/DOWN, không lọc các bit subtrim/scan khác
    static uint16_t nav_stable = 0;
    static uint16_t nav_last   = 0;
    static uint8_t  nav_same   = 0;
    static uint16_t nav_prev   = 0;

    uint16_t nav = (uint16_t)(in->btn_mask & BTN_NAV_MASK);

    // Debounce nhẹ: cần giống nhau >= 2 lần liên tiếp (nav_same >= 1)
    if (nav == nav_last) {
        if (nav_same < 3) nav_same++;
    } else {
        nav_last = nav;
        nav_same = 0;
    }
    if (nav_same >= 1) nav_stable = nav;

    // Rising edge trên nav_stable
    uint16_t pressed = (uint16_t)(nav_stable & (uint16_t)~nav_prev);
    nav_prev = nav_stable;

    int ok   = (pressed & BTN_OK_BIT)   ? 1 : 0;
    int back = (pressed & BTN_BACK_BIT) ? 1 : 0;
    int up   = (pressed & BTN_UP_BIT)   ? 1 : 0;
    int down = (pressed & BTN_DOWN_BIT) ? 1 : 0;

    // (Optional) Cooldown ngắn chống double-click do rung (80ms)
    // Nếu anh thấy bấm 1 cái mà nhảy 2 lần, bật đoạn này:
    /*
    static uint32_t nav_cd_ms = 0;
    uint32_t now = HAL_GetTick();
    if (pressed && (now - nav_cd_ms < 80)) {
        ok = back = up = down = 0;
    }
    if (pressed) nav_cd_ms = now;
    */

    // ================= NAVIGATION =================
    if (ui_screen == UI_HOME) {
        if (ok) { ui_screen = UI_MENU; menu_idx = 0; }
    }
    else if (ui_screen == UI_MENU) {
        if (up && menu_idx > 0) menu_idx--;
        if (down && menu_idx < 5) menu_idx++;

        if (ok) {
            if (menu_idx == 0) ui_screen = UI_HOME;
            else if (menu_idx == 1) ui_screen = UI_AXES;
            else if (menu_idx == 2) { ui_screen = UI_IO; io_page = 0; }
            else if (menu_idx == 3) ui_screen = UI_SUBTRIM;
            else if (menu_idx == 4) { ui_screen = UI_CALIB; cal_state = CAL_IDLE; }
            else if (menu_idx == 5) ui_screen = UI_ABOUT;
        }
        if (back) ui_screen = UI_HOME;
    }
    else if (ui_screen == UI_IO) {
        if (back) ui_screen = UI_HOME;
        else if (ok) io_page ^= 1; // OK đổi trang POT/SW
    }
    else if (ui_screen == UI_CALIB) {
        if (back) {
            cal_state = CAL_IDLE;
            calib_reset_working();
            ui_screen = UI_HOME;
        } else if (ok) {
            if (cal_state == CAL_IDLE) {
                calib_reset_working();
                cal_state = CAL_RECORDING;
            } else if (cal_state == CAL_RECORDING) {
                cal_state = CAL_CENTER;
            } else if (cal_state == CAL_CENTER) {
                // capture centers
                cal_ctr_w[CAL_AX] = in->ax_raw;
                cal_ctr_w[CAL_AY] = in->ay_raw;
                cal_ctr_w[CAL_AZ] = in->az_raw;
                cal_ctr_w[CAL_AR] = in->arx_raw;
                cal_ctr_w[CAL_P1] = in->pot1_raw;
                cal_ctr_w[CAL_P2] = in->pot2_raw;
                cal_ctr_w[CAL_P3] = in->pot3_raw;

                for (int i = 0; i < 7; i++) {
                    gConfig.cal_min[i] = cal_min_w[i];
                    gConfig.cal_max[i] = cal_max_w[i];
                    gConfig.cal_ctr[i] = cal_ctr_w[i];
                }
                Config_Save();
                cal_state = CAL_SAVED;
            } else {
                cal_state = CAL_IDLE;
            }
        }
    }
    else {
        if (back) ui_screen = UI_HOME;
    }

    // ================= DRAW =================
    switch (ui_screen) {
        case UI_HOME:    draw_home(in);    break;
        case UI_MENU:    draw_menu();      break;
        case UI_AXES:    draw_axes(in);    break;
        case UI_IO:      draw_io(in);      break;
        case UI_SUBTRIM: draw_subtrim(in); break;
        case UI_CALIB:   draw_calib(in);   break;
        case UI_ABOUT:   draw_about();     break;
        default:         draw_home(in);    break;
    }
}

